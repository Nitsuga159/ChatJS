<?php
if(empty($_POST['name']) || empty($_POST['email']) || empty($_POST['message']) || !filter_var($_POST['email'])) {
  echo "No has rellenado todos los datos";
  return false;
}

$name = $_POST['name'];
$email_address = $_POST['email'];
$message = $_POST['message'];

$to = 'agoccre@gmail.com';
$email_subject = "Nuevo correo de: $name";
$email_body = "Nuevo mensaje del formulario de contacto.\n\n";
$headers = "Desde: agoccr@gmail.com\n";
$headers = "Responder a: $email_address";
mail($to, $email_subject, $email_body, $headers);
return true;
 ?>

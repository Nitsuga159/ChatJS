<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/icomoon/style.css">
</head>
<body>
<header>
  <nav class="green darken-1">
    <div class="nav-wrapper">
      <a href="index.php" class="brand-logo hide-on-small-only">
        <img src="img/logo.png" alt="Logo de la Marca" style="height: 250px;
        margin-left: 5px;
        margin-right: 5px; padding-bottom: 100px;">

      </a>
          <ul id="nav-mobile" class="right">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="sobre-nosotros.php">Sobre Nosotros</a></li>
            <li><a href="contacto.php">Contacto</a></li>
            <li><a href="servicios.php">Servicios</a></li>
          </ul>
        </div>
      </nav>
    </header>

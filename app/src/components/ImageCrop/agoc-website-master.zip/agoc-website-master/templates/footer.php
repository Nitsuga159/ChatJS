
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<footer class="page-footer green darken-1 my-footer">
<div class="row">
  <div class="col s2">
    <img src="img/logo.png" alt="" class="responsive-img center-align">
  </div>
  <div class="col s5">
    <h5 class="center-align">Agrupación Gastronómica de Occidente</h5>
  </div>
  <div class="col s5">
    <h5 class="center-align">Enlaces de interés</h5>
    <br>
    <div class="row center-align">
      <a  target="_blank" href="https://www.instagram.com/agoccr/"><span class="icon-instagram"></span></a>
      <a  target="_blank" href="https://www.facebook.com/profile.php?id=100093164432573"><span class="icon-facebook"></span></a>
      <a  target="_blank" href="https://twitter.com/agoccr"><span class="icon-twitter"></span></a>
      <a  target="_blank" href="https://api.whatsapp.com/send/?phone=50689508913&text&type=phone_number&app_absent=0"><span class="icon-whatsapp"></span></a>
    </div>
  </div>
</div>
</footer>
</body>
</html>

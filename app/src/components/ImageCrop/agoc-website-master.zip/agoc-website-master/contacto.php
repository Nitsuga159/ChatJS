<?php require_once "templates/header.php" ?>
<title>AGOC - CONTACTO</title>
<!-- Compiled and minified CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
</head>
<body>
   <div class="parallax-container">
      <div class="parallax"><img src="img/webp/5.webp" class="responsive-img"></div>
      <div class="parallax-text">
         <h2 class="center-align">Agrupación Gastronómica de Occidente - Contacto</h2>
         <p class="flow-text center-align">Somos una organización que busca el bienestar colectivo de cada uno de sus miembros a través de la tecnología</p>
      </div>
   </div>
   <!-- Resto del contenido de la página -->
   <!-- Compiled and minified JavaScript -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
   <script>
      document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('.parallax');
        var instances = M.Parallax.init(elems);
      });
   </script>
   <div class="container">
      <div class="row">
         <div class="col s12 m6">
            <div class="card">
               <div class="card-content">
                  <span class="card-title">Formulario de Contacto</span>
                  <form method="post" action="mail/contact_me.php">
                     <div class="input-field">
                        <input type="text" name="name" id="name" class="validate">
                        <label for="name">Nombre</label>
                     </div>
                     <div class="input-field">
                        <input type="email" name="email" id="email" class="validate">
                        <label for="email">Correo Electrónico</label>
                     </div>
                     <div class="input-field">
                        <textarea name="message" id="message" class="materialize-textarea"></textarea>
                        <label for="message">Mensaje</label>
                     </div>
                     <button class="btn waves-effect waves-light" type="submit">Enviar</button>
                  </form>
               </div>
            </div>
         </div>
         <div class="col s12 m6">
            <div class="card">
               <div class="card-content">
                  <iframe
                     width="100%"
                     height="450"
                     style="border:0"
                     loading="lazy"
                     allowfullscreen
                     referrerpolicy="no-referrer-when-downgrade"
                     src="https://www.google.com/maps/embed/v1/place?key=AIzaSyD_2z293cUDHSy4YO9_Cj8FP4CNWFIJln4&q=San+ramon+alajuela"></iframe>
               </div>
            </div>
         </div>
      </div>
   </div>
   <?php require_once "templates/footer.php" ?>

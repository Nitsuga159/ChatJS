<!DOCTYPE html>
<html>
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>AGOC - Tu plataforma de soluciones gastronómicas líder</title>
      <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
      <!-- Materialize CSS -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
      <!-- Material Icons -->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link rel="stylesheet" href="css/styles.css">
      <link rel="stylesheet" href="css/icomoon/style.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Roboto+Serif:wght@700&display=swap" rel="stylesheet">
      <style>
         @font-face {
         font-family: 'Roboto Serif', serif;
         }
         body {
         background-color: #f5f5f5;
         margin-bottom: 0;
         }
         .slider {
         position: relative;
         z-index: 1;
         max-height: 500px; /* Ajusta la altura máxima según tus preferencias */
         margin-bottom: 20px; /* Agrega margen inferior para crear espacio entre el slider y el contenido siguiente */
         }
         .slider .slide {
         position: relative;
         height: 100%; /* Asegura que cada slide ocupe el 100% de la altura del slider */
         }
         .slider .slide img {
         width: 100%;
         height: 600px; /* Asegura que las imágenes ocupen el 100% de la altura del slide */
         object-fit: cover; /* Ajusta el recorte de las imágenes para llenar el espacio disponible */
         }
         .slider .caption {
         position: absolute;
         bottom: 20px;
         right: 20px;
         background-color: rgba(0, 0, 0, 0.6);
         padding: 10px;
         color: #ffffff;
         width: 400px;
         height: 100px;
         z-index: 2;
         }
         .slider .caption h3 {
         margin: 0;
         font-size: 16px;
         }
         .navbar {
         position: fixed;
         top: 0;
         width: 100%;
         z-index: 999;
         }
      </style>
   </head>
   <body>
      <!-- Dropdow -->
      <ul id="directorio" class="dropdown-content orange darken-3">
         <li><a href="#!" class="white-text">Pet Friendly</a></li>
         <li><a href="#!" class="white-text">Familiares</a></li>
         <li><a href="#!" class="white-text">Veganos</a></li>
         <li><a href="#!" class="white-text">Vegetarianos</a></li>
         <li><a href="#!" class="white-text">Celiacos</a></li>
      </ul>
      <ul id="directorio-mobil" class="dropdown-content orange darken-3">
         <li><a href="#!" class="white-text">Pet Friendly</a></li>
         <li><a href="#!" class="white-text">Familiares</a></li>
         <li><a href="#!" class="white-text">Veganos</a></li>
         <li><a href="#!" class="white-text">Vegetarianos</a></li>
         <li><a href="#!" class="white-text">Celiacos</a></li>
      </ul>
      <!-- Navbar -->
      <nav class="navbar hide-on-med-and-down" style="background-color: #560530;">
         <div class="nav-wrapper">
            <a href="#" class="brand-logo left hide-on-small-only"> <img src="img/logo_blanco.png" alt="" style="height: 200px;
               margin-left: 55px;
               margin-right: 5px; padding-bottom: 120px;"> </a>
            <ul class="right hide-on-med-and-down">
               <li><a href="#inicio" class="white-text">Inicio</a></li>
               <li><a href="#servicios" class="white-text">Servicos</a></li>
               <li><a href="#ruta-gastronomica" class="white-text">Ruta Gastronómica</a></li>
               <li><a href="#tips" class="white-text">Tips</a></li>
               <li><a href="#productos" class="white-text">Productos</a></li>
               <li><a href="#eventos" class="white-text">Eventos</a></li>
               <li><a href="#paquetes" class="white-text">Paquetes</a></li>
               <li><a href="#sobre-nosotros" class="white-text">Sobre Nosotros</a></li>
               <li><a href="#contacto" class="white-text">Contacto</a></li>
               <li> <a href="#!" class="dropdown-trigger" data-target="directorio">Directorio<i class="material-icons right">arrow_drop_down</i></a> </li>
               <li><a href="#contacto" class="btn orange darken-3">Comunidad</a></li>
            </ul>
         </div>
      </nav>
      <!-- Mobile Navbar -->
      <nav class="navbar hide-on-large-only" style="background-color: #560530;">
         <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
      </nav>
      <ul class="sidenav" id="mobile-nav" style="background-color: #560530;">
         <li><a href="#inicio" class="white-text">Inicio</a></li>
         <li><a href="#servicios" class="white-text">Servicos</a></li>
         <li><a href="#ruta-gastronomica" class="white-text">Ruta Gastronómica</a></li>
         <li><a href="#tips" class="white-text">Tips</a></li>
         <li><a href="#productos" class="white-text">Productos</a></li>
         <li><a href="#eventos" class="white-text">Eventos</a></li>
         <li><a href="#paquetes" class="white-text">Paquetes</a></li>
         <li><a href="#sobre-nosotros" class="white-text">Sobre Nosotros</a></li>
         <li><a href="#contacto" class="white-text">Contacto</a></li>
         <li> <a href="#!" class="dropdown-trigger white-text" data-target="directorio-mobil">Directorio<i class="material-icons right">arrow_drop_down</i></a> </li>
         <li><a href="#contacto" class="btn orange darken-3">Comunidad</a></li>
      </ul>
      <!-- Hero Section -->
      <section id="inicio">
         <div class="slider">
            <div class="slide">
               <img src="img/jpg/6.jpg" alt="Imagen 1" class="responsive-img">
               <div class="caption">
                  <br>
                  <h3 class="center-align">¡Descubre AGOC, la plataforma líder en soluciones tecnológicas gastronómicas que transformará por completo tu negocio!</h3>
               </div>
            </div>
            <div class="slide">
               <img src="img/jpg/2.jpg" alt="Imagen 2" class="responsive-img">
               <div class="caption">
                  <br>
                  <h3 class="center-align">¡Explora nuestro directorio comercial y descubre un mundo de oportunidades para tu negocio!</h3>
               </div>
            </div>
            <div class="slide">
               <img src="img/jpg/3.jpg" alt="Imagen 3" class="responsive-img">
               <div class="caption">
                  <h3 class="center-align">¡Potencia tu negocio y alcanza nuevos niveles de éxito con nuestras herramientas tecnológicas especializadas!</h3>
               </div>
            </div>
         </div>
         <div class="container">
         </div>
      </section>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <section id="servicios">
         <h3 class="center-align">Servicios</h3>
         <br>
         <br>
         <div class="container">
            <div class="row">
               <div class="col s4 hoverable">
                  <img src="img/jpg/21.jpg" alt="" class="center-align circle responsive-img materialboxed" style="width:300px; height:350px;">
                  <h5 class="center-align">Asesorías</h5>
                  <p class="center-align">AGOC otorga asesoría, acompañamiento, así como soporte técnico a cada uno de sus miembros. En el canal de YouTube, la comunidad de AGOC podrá acceder una vez a la semana a nuevos contenidos, además de los videos explicativos del uso de cada una de las herramientas tecnológicas que ofrecemos a nuestros usuarios.</p>
               </div>
               <div class="col s4 hoverable">
                  <img src="img/jpg/20.jpg" alt="" class="center-align circle responsive-img materialboxed" style="width:300px; height:350px;">
                  <h5 class="center-align">Directorio</h5>
                  <p class="center-align">Ponemos a disposición de todas las personas que buscan disfrutar de una nueva experiencia gastronómica, compartir en familia, deseosas de conocer un nuevo lugar o simplemente quitarse un antojo, el directorio gastronómico más surtido y completo de todo el país.</p>
               </div>
               <div class="col s4 hoverable">
                  <img src="img/jpg/11.jpg" alt="" class="center-align circle responsive-img materialboxed" style="width:300px; height:350px;">
                  <h5 class="center-align">Software</h5>
                  <p class="center-align">Los mejores paquetes de software para el sector gastronómico, con todo tipo de módulos, funciones y aplicaciones. Contamos con los programas e interfaces más completos para trabajar de manera efectiva, sencilla y ordenada.</p>
               </div>
            </div>
         </div>
      </section>
      <br>
      <br>
      <br>
      <section id="ruta-gastronomica" class="hoverable">
         <div class="row">
            <h3 class="center-align">Ruta Gastronómica</h3>
            <br>
         </div>
         <div class="row">
            <div class="col s6">
               <img src="img/webp/8.webp" alt="" class="responsive-img" style="height: 300px; width:100%; object-fit: fill; margin-top:30px;">
            </div>
            <div class="col s6">
               <br>
               <br>
               <br>
               <br>
               <p class="center-align  ">Esta sección es donde conoceremos los diversos sabores de la comida tradicional costarricense, sus diversos sabores, formas y matices en los distintos rincones de nuestro país. Acompáñenos a conocer desde las comidas más tradicionales hasta los más diversos y deliciosos platillos servidos en Costa Rica.</p>
            </div>
         </div>
      </section>
      <section id="tips" class="hoverable">
         <div class="row ">
            <h3 class="center-align" style="margin-top: 100px;">Tips</h3>
            <br>
         </div>
         <div class="row">
            <div class="col s6">
               <br>
               <br>
               <br>
               <br>
               <p class="center-align  ">En "Tips" usted encontrará una gran variedad de consejos, recetas, aportes y una amplia gama de opciones para poder implementar mejoras en su cocina, sorprender a sus invitados o gestionar mejor las compras diarias en su hogar. "Tips" es la sección de todos aquellos consejos gastronómicos que nunca nos había dicho pero que tanto necesitamos.</p>
            </div>
            <div class="col s6">
               <img src="img/jpg/5.jpg" alt="" class="responsive-img" style="height: 300px; width:100%; object-fit: fill; margin-top:30px;">
            </div>
         </div>
      </section>
      <section id="productos" class="hoverable">
         <div class="row ">
            <h3 class="center-align" style="margin-top: 100px;">Productos</h3>
            <br>
         </div>
         <div class="row">
            <div class="col s6">
               <img src="img/jpg/22.jpg" alt="" class="responsive-img" style="height: 300px; width:100%; object-fit: fill; margin-top:30px;">
            </div>
            <div class="col s6">
               <br>
               <br>
               <br>
               <br>
               <p class="center-align  ">En esta sección usted podrá obtener acceso a productos gastronómicos únicos, exclusivos de importación o exportación. Tenemos desde nuevos productos nacionales hasta productos extranjeros exclusivos, para poder disfrutar por salud o deleite particular.</p>
            </div>
         </div>
      </section>
      <section id="eventos" class="hoverable">
         <div class="row ">
            <h3 class="center-align" style="margin-top: 100px;">Eventos</h3>
            <br>
         </div>
         <div class="row">
            <div class="col s6">
               <br>
               <br>
               <br>
               <br>
               <p class="center-align  ">Como bien lo dice el nombre, todos los grandes eventos gastronómicos estarán aquí: catas, conciertos, música en vivo, ferias, exposiciones, karaokes y todo lo que usted pueda disfrutar mientras disfruta de una buena comida lo encontrará aquí.</p>
            </div>
            <div class="col s6">
               <img src="img/jpg/16.jpg" alt="" class="responsive-img" style="height: 300px; width:100%; object-fit: fill; margin-top:30px;">
            </div>
         </div>
      </section>
      <!-- Paquetes Section -->
      <section id="paquetes" style="margin-top: 200px; background-color:#f06292; padding-top:100px; padding-bottom:100px;">
         <h3 class="center-align white-text" style="margin-bottom:40px;">PAQUETES</h3>
         <div class="row">
            <div class="col s12 m4">
               <div class="card hoverable">
                  <div class="card-content">
                     <span class="card-title center-align">Paquete Básico</span>
                     <blockquote class="center-align">Precio: ₡15.000 mensuales</blockquote>
                  </div>
                  <div class="card-action center-align">
                     <a class="waves-effect waves-light btn modal-trigger orange darken-3" href="#modal-basico">Ver detalles</a>
                  </div>
               </div>
            </div>
            <div class="col s12 m4">
               <div class="card hoverable">
                  <div class="card-content">
                     <span class="card-title center-align">Paquete Intermedio</span>
                     <blockquote class="center-align">Precio: ₡55.000 mensuales</blockquote>
                  </div>
                  <div class="card-action center-align">
                     <a class="waves-effect waves-light btn modal-trigger orange darken-3" href="#modal-intermedio">Ver detalles</a>
                  </div>
               </div>
            </div>
            <div class="col s12 m4">
               <div class="card hoverable">
                  <div class="card-content">
                     <span class="card-title center-align">Paquete de Fidelización</span>
                     <blockquote class="center-align">Precio: ₡75.000 mensuales</blockquote>
                  </div>
                  <div class="card-action center-align">
                     <a class="waves-effect waves-light btn modal-trigger orange darken-3" href="#modal-fidelizacion">Ver detalles</a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Modals -->
      <div id="modal-basico" class="modal">
         <div class="modal-content">
            <h4 class="center-align">Paquete Básico</h4>
            <blockquote class="center-align flow-text">Precio: ₡15.000 mensuales</blockquote>
            <ul>
               <li class="flow-text"><i class="material-icons">stars</i>Acceso al blog para anunciar eventos.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Acceso al directorio gastronómico.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Creación de página web básica para presencia en internet.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Acceso al canal de YouTube para capacitaciones y charlas.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Descuento en eventos futuros.</li>
            </ul>
         </div>
         <div class="modal-footer">
            <a href="#!" class="modal-close waves-effect waves-light btn">Cerrar</a>
         </div>
      </div>
      <div id="modal-intermedio" class="modal">
         <div class="modal-content">
            <h4 class="center-align">Paquete Intermedio</h4>
            <blockquote class="center-align flow-text">Precio: ₡55.000 mensuales</blockquote>
            <ul>
               <li class="flow-text"><i class="material-icons">stars</i>Todos los beneficios del paquete básico.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Software de punto de venta para restaurantes.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Software con administración del negocio CRM.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Software para ecommerce o venta en línea de comida.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Sistema para hacer reservaciones.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Sistema de gestión de compras.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Sistema de gestión de divisas.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Sistema de gestión de pedidos.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Sistema de gestión de producción.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Panel de control.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Informes en tiempo real.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Método de pago.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Administración de cuentas.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Administración de recursos humanos.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Método de envío.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Gestión de mesas de restaurante.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Sistema multilingüe.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Unidad e ingredientes de cocina.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Participación con presencia de marca en eventos.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Acceso a cursos especializados.</li>
            </ul>
         </div>
         <div class="modal-footer">
            <a href="#!" class="modal-close waves-effect waves-light btn">Cerrar</a>
         </div>
      </div>
      <div id="modal-fidelizacion" class="modal">
         <div class="modal-content">
            <h4 class="center-align">Paquete de Fidelización</h4>
            <blockquote class="flow-text center-align">Precio: ₡75.000 mensuales</blockquote>
            <ul>
               <li class="flow-text"><i class="material-icons">stars</i>Todos los beneficios del paquete intermedio.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Ser miembro reconocido de la comunidad AGOC.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Acceso a perfil de cliente.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Acceso a campañas estratégicas.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Acceso de métricas mensuales.</li>
               <li class="flow-text"><i class="material-icons">stars</i>Acceso a proveedores.</li>
            </ul>
         </div>
         <div class="modal-footer">
            <a href="#!" class="modal-close waves-effect waves-light btn">Cerrar</a>
         </div>
      </div>
      <!-- Preguntas Frecuentes Section -->
      <section id="sobre-nosotros">
         <div class="container">
            <h4 class="center-align">Sobre Nosotros</h4>
            <div class="row">
               <div class="col s12">
                  <div class="card">
                     <div class="card-content">
                        <p class="center-align">AGOC es tu socio estratégico en el mundo gastronómico, brindándote soluciones tecnológicas de vanguardia. Nuestra plataforma está diseñada para optimizar tus operaciones y mejorar la experiencia de tus clientes. Desde sistemas de gestión de pedidos en línea hasta herramientas de automatización, AGOC te proporciona las soluciones adecuadas para llevar tu negocio gastronómico al siguiente nivel. Nuestro equipo de expertos estará contigo en cada paso del camino, brindándote asesoramiento personalizado para aprovechar al máximo el potencial de la tecnología. Únete a AGOC y descubre cómo nuestras soluciones tecnológicas avanzadas pueden impulsar tu éxito en la industria gastronómica.</p>
                        <br>
                        <p class="center-align">No te conformes con lo ordinario en el mundo gastronómico. Con AGOC, podrás destacarte y marcar la diferencia. Optimiza tus operaciones diarias, agiliza tus procesos y brinda una experiencia excepcional a tus clientes. Nuestro enfoque centrado en la innovación y la eficiencia te permitirá alcanzar nuevas alturas de éxito. Descubre cómo nuestras soluciones tecnológicas personalizadas pueden transformar tu negocio gastronómico y llévalo hacia el futuro. No esperes más, únete a AGOC y prepárate para un viaje emocionante hacia el crecimiento y la excelencia en la industria gastronómica.</p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row hide-on-med-and-down">
               <div class="col s6">
                  <div class="card">
                     <div class="card-image">
                        <img src="img/jpg/8.jpg" alt="" class="responsive-img">
                     </div>
                     <div class="card-title center-align">
                        Misión
                     </div>
                     <div class="card-content center-align">
                        <p>Ser una agrupación que otorgue soluciones de innovación digital y asesoría técnica. Acompañando a nuestros miembros en la implementación de tecnologías (software y Hardware), que les permita mejorar, desarrollar e implementar servicio integral y posicionamiento de su negocio.</p>
                     </div>
                  </div>
               </div>
               <div class="col s6">
                  <div class="card">
                     <div class="card-image">
                        <img src="img/jpg/10.jpg" alt="" class="responsive-img">
                     </div>
                     <div class="card-title center-align">
                        Visión
                     </div>
                     <div class="card-content center-align">
                        <br>
                        <p>Ser la comunidad de empresarios y emprendimientos gastronómicos que aporte soluciones técnicas y tecnologicas de manera solidaria. Buscando el beneficio económico y profesional de la gastronomía nacional.</p>
                        <br>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row hide-on-large-only">
               <div class="col s12">
                  <div class="card">
                     <div class="card-image">
                        <img src="img/jpg/19.jpg" alt="" class="responsive-img">
                     </div>
                     <div class="card-title center-align">
                        Misión
                     </div>
                     <div class="card-content center-align">
                        <p>Ser una agrupación que otorgue soluciones de innovación digital y asesoría técnica. Acompañando a nuestros miembros en la implementación de tecnologías (software y Hardware), que les permita mejorar, desarrollar e implementar servicio integral y posicionamiento de su negocio.</p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row hide-on-large-only">
               <div class="col s12">
                  <div class="card">
                     <div class="card-image">
                        <img src="img/jpg/19.jpg" alt="" class="responsive-img">
                     </div>
                     <div class="card-title center-align">
                        Visión
                     </div>
                     <div class="card-content center-align">
                        <br>
                        <p>Ser la comunidad de empresarios y emprendimientos gastronómicos que aporte soluciones técnicas y tecnologicas de manera solidaria. Buscando el beneficio económico y profesional de la gastronomía nacional.</p>
                        <br>
                     </div>
                  </div>
               </div>
            </div>
            <h4 class="center-align">Preguntas Frecuentes</h4>
            <ul class="collapsible">
               <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Quién lidera la comunidad de empresarios y emprendimientos gastronómicos comprometidos en ofrecer soluciones técnicas y tecnológicas innovadoras para el sector?</div>
                  <div class="collapsible-body">
                     <span>AGOC, la Agrupación Gastronómica de Occidente, lidera con orgullo la comunidad de empresarios y emprendimientos gastronómicos comprometidos en ofrecer soluciones técnicas y tecnológicas innovadoras para el sector. Nos destacamos por nuestra pasión y compromiso en impulsar el desarrollo de la gastronomía mediante la integración de la tecnología en el ámbito culinario.</span>
                  </div>
               </li>
               <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿En qué se enfoca AGOC al brindar soluciones a sus miembros?</div>
                  <div class="collapsible-body">
                     <span>AGOC se enfoca en proporcionar a sus miembros soluciones integrales y de vanguardia. A través de nuestra amplia experiencia y conocimiento en innovación digital y asesoría técnica, brindamos el respaldo necesario para que los empresarios y emprendedores gastronómicos puedan adoptar las últimas tecnologías, tanto en software como en hardware, mejorando así su desempeño y competitividad en el mercado.</span>
                  </div>
               </li>
               <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Cuál es el objetivo principal de AGOC?</div>
                  <div class="collapsible-body">
                     <span>Nuestro objetivo principal en AGOC es impulsar el crecimiento económico y profesional de la gastronomía nacional. Trabajamos arduamente para fortalecer la industria, colaborando estrechamente con nuestros miembros para fomentar la excelencia en el sector gastronómico y promover su reconocimiento a nivel nacional e internacional.</span>
                  </div>
               </li>
               <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Qué se promueve en la comunidad de AGOC?</div>
                  <div class="collapsible-body">
                     <span>En AGOC promovemos una comunidad sólida y colaborativa, donde los empresarios y emprendedores gastronómicos pueden conectarse, interactuar y compartir conocimientos y experiencias. Fomentamos un ambiente de apoyo mutuo, impulsando la colaboración y la sinergia entre nuestros miembros. Creemos en el poder de la comunidad para superar desafíos y alcanzar metas comunes.</span>
                  </div>
               </li>
               <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Qué ofrece AGOC para impulsar el éxito de sus miembros?</div>
                  <div class="collapsible-body">
                     <span>Para impulsar el éxito de nuestros miembros, AGOC ofrece una amplia gama de beneficios. Además de brindar soluciones tecnológicas y asesoría técnica de vanguardia, también proporcionamos oportunidades de networking, eventos exclusivos, acceso a recursos y herramientas especializadas, y la posibilidad de participar en proyectos conjuntos. Nuestro enfoque integral busca potenciar el crecimiento y la visibilidad de nuestros miembros en el mercado gastronómico.</span>
                  </div>
               </li>
               <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Cuál es la invitación final de AGOC para los interesados en unirse a la comunidad?</div>
                  <div class="collapsible-body">
                     <span>La invitación final de AGOC es a unirse a nuestra comunidad y formar parte de la transformación tecnológica e innovadora en el sector gastronómico. Si eres un empresario o emprendedor gastronómico en busca de soluciones y apoyo para alcanzar tus metas, te animamos a unirte a AGOC y ser parte de una comunidad comprometida en impulsar el éxito y el crecimiento colectivo en la gastronomía nacional. ¡Te damos la bienvenida a AGOC, tu plataforma de soluciones gastronómicas líder!</span>
                  </div>
               </li>
            </ul>
         </div>
      </section>
      <section id="newsletter" class="pink lighten-1" style="padding-top:50px; padding-bottom:50px;">
         <div class="row">
            <h4 class="white-text center-align">Suscribete a nusertro newletter para estar al tanto de las últimas novedades.</h4>
         </div>
         <form class="" action="mail/newletter.php" method="post">
            <div class="row">
               <div class="input-field col s12">
                  <input type="email" id="correo" name="correo" class="white-text" required>
                  <label for="email" class="white-text" ><i class="material-icons">email</i> Correo electrónico:</label>
               </div>
            </div>
            <div class="row">
               <div class="col s12 center-align">
                  <button type="submit" value="suscribirse" class="btn-large orange darken-3" name="suscribirse">Susucribirse</button>
               </div>
            </div>
         </form>
      </section>
      <section id="contacto">
         <div class="container">
            <div class="row">
               <div class="col s6">
                  <div class="card">
                     <div class="card-content">
                        <span class="card-title">Formulario de Contacto</span>
                        <form method="post" action="mail/contact_me.php">
                           <div class="input-field">
                              <input type="text" name="name" id="name" class="validate">
                              <label for="name">Nombre</label>
                           </div>
                           <div class="input-field">
                              <input type="email" name="email" id="email" class="validate">
                              <label for="email">Correo Electrónico</label>
                           </div>
                           <div class="input-field">
                              <textarea name="message" id="message" class="materialize-textarea"></textarea>
                              <label for="message">Mensaje</label>
                           </div>
                           <button class="btn waves-effect waves-light" type="submit">Enviar</button>
                        </form>
                     </div>
                  </div>
               </div>
               <div class="col s6">
                  <div class="card">
                     <div class="card-content">
                        <iframe
                           width="100%"
                           height="288px"
                           style="border:0"
                           loading="lazy"
                           allowfullscreen
                           referrerpolicy="no-referrer-when-downgrade"
                           src="https://www.google.com/maps/embed/v1/place?key=AIzaSyD_2z293cUDHSy4YO9_Cj8FP4CNWFIJln4&q=San+ramon+alajuela"></iframe>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         </div>
      </section>
      <!-- Footer -->
      <footer class="page-footer" style="background-color: #560530; display: flex; bottom:0; width: 100%">
         <div class="container">
            <div class="row hide-on-med-and-down">
               <div class="col s8">
                  <h5 class="center-align">Enlaces de interés</h5>
                  <div class="row">
                     <a href="#" class="white-text">Politicas de Uso</a>
                  </div>
                  <div class="row">
                     <a href="#" class="white-text">Politicas de Cookies</a>
                  </div>
                  <div class="row">
                     <a href="#" class="white-text">Politicas de Privacidad</a>
                  </div>
               </div>
               <div class="col s4">
                  <div class="row center-align" style=" margin-right: 60px;">
                     <h5>Nuestras redes sociales</h5>
                     <br>
                     <br>
                     <a  target="_blank" href="https://www.instagram.com/agoccr/"><span class="icon-instagram"></span></a>
                     <a  target="_blank" href="https://www.facebook.com/profile.php?id=100093164432573"><span class="icon-facebook"></span></a>
                     <a  target="_blank" href="https://twitter.com/agoccr"><span class="icon-twitter"></span></a>
                     <a  target="_blank" href="https://api.whatsapp.com/send/?phone=50689508913&text&type=phone_number&app_absent=0"><span class="icon-whatsapp"></span></a>
                     <a  target="_blank" href="https://api.whatsapp.com/send/?phone=50689508913&text&type=phone_number&app_absent=0"><span class="icon-youtube"></span></a>
                  </div>
               </div>
            </div>
            <div class="row hide-on-large-only center-align">
               <div class="col s12">
                  <h5 class="center-align">Enlaces de interés</h5>
                  <div class="row">
                     <a href="#" class="white-text">Politicas de Uso</a>
                  </div>
                  <div class="row">
                     <a href="#" class="white-text">Politicas de Cookies</a>
                  </div>
                  <div class="row">
                     <a href="#" class="white-text">Politicas de Privacidad</a>
                  </div>
               </div>
            </div>
            <div class="row hide-on-large-only center-align">
               <div class="col s12">
                  <div class="row center-align">
                     <h5>Nuestras redes sociales</h5>
                     <a  target="_blank" href="https://www.instagram.com/agoccr/"><span class="icon-instagram"></span></a>
                     <a  target="_blank" href="https://www.facebook.com/profile.php?id=100093164432573"><span class="icon-facebook"></span></a>
                     <a  target="_blank" href="https://twitter.com/agoccr"><span class="icon-twitter"></span></a>
                     <a  target="_blank" href="https://api.whatsapp.com/send/?phone=50689508913&text&type=phone_number&app_absent=0"><span class="icon-whatsapp"></span></a>
                     <a  target="_blank" href="https://api.whatsapp.com/send/?phone=50689508913&text&type=phone_number&app_absent=0"><span class="icon-youtube"></span></a>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
      <!-- Materialize JS -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <script>
         // Initialize Materialize components
         document.addEventListener('DOMContentLoaded', function () {
           var elems = document.querySelectorAll('.sidenav');
           var instances = M.Sidenav.init(elems);

           var modals = document.querySelectorAll('.modal');
           M.Modal.init(modals);

           var collapsibles = document.querySelectorAll('.collapsible');
           M.Collapsible.init(collapsibles);
         });
         document.addEventListener("DOMContentLoaded", function() {
           var carousels = document.querySelectorAll(".carousel");
           M.Carousel.init(carousels, {
             fullWidth: true,
             indicators: true
           });
         });

         document.addEventListener("DOMContentLoaded", function() {
           var dropdowns = document.querySelectorAll(".dropdown-trigger");
           M.Dropdown.init(dropdowns);
         });

         $(document).ready(function(){
           $('.slider').slick({
             dots: false,
             autoplay: true,
             arrows: false,
             autoplaySpeed: 6000,
             speed: 700,
             adaptiveHeight: true
           });
         });
         document.addEventListener('DOMContentLoaded', function() {
         var elems = document.querySelectorAll('.materialboxed');
         var instances = M.Materialbox.init(elems);
         });
      </script>
   </body>
</html>

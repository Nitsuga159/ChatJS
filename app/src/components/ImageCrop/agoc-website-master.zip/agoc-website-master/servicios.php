<?php require_once "templates/header.php" ?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>AGOC - SERVICIOS</title>
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link rel="stylesheet" href="/css/styles.css">
  </head>
  <body>
    <div class="parallax-container">
      <div class="parallax"><img src="img/webp/5.webp" class="responsive-img"></div>
      <div class="parallax-text">
        <h2 class="center-align">Agrupación Gastronómica de Occidente - Servicios</h2>
        <p class="flow-text center-align">Nuestros servicios están pensados y desarrollados para que cualquier tipo de negocio, pequeño o grande; especializado o no, pueda encontrar un beneficio que se acomode a su presupuesto y su necesidad.</p>
      </div>
    </div>

    <!-- Resto del contenido de la página -->

    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('.parallax');
        var instances = M.Parallax.init(elems);
      });
    </script>
    <div class="container">
  <div class="row">
    <!-- Componentes para pantallas grandes -->
    <div class="col s4 hide-on-small-only">
      <div class="card hoverable">
        <div class="card-image">
          <img src="img/webp/11.webp" alt="" class="responsive-img">
        </div>
        <div class="card-content">
          <h5>Paquete básico</h5>
          <blockquote>
            <p>Precio</p>
            <p>₡15.000 mensuales</p>
          </blockquote>
          <p> - Acceso al blog para anunciar eventos.</p>
          <p> - Acceso al directorio gastronómico.</p>
          <p> - Creación de página web básica para presencia en internet.</p>
          <p> - Acceso al canal de YouTube para capacitaciones y charlas.</p>
          <p> - Descuento en eventos futuros.</p>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
        </div>
      </div>
    </div>
    <div class="col s4 hide-on-small-only">
      <div class="card hoverable">
        <div class="card-image">
          <img src="img/webp/2.webp" alt="" class="responsive-img">
        </div>
        <div class="card-content">
          <h5>Paquete intermedio</h5>
          <blockquote>
            <p>Precio</p>
            <p>₡55.000 mensuales</p>
          </blockquote>
          <p> - Todos los beneficios del paquete básico.</p>
          <p> - Software de punto de venta para restaurantes.</p>
          <p> - Software con administración del negocio CRM.</p>
          <p> - Software para ecommerce o venta en línea de comida.</p>
          <p> - Sistema para hacer reservaciones.</p>
          <p> - Sistema de gestión de compras.</p>
          <p> - Sistema de gestión de divisas.</p>
          <p> - Sistema de gestión de pedidos.</p>
          <p> - Sistema de gestión de producción.</p>
          <p> - Panel de control.</p>
          <p> - Informes en tiempo real.</p>
          <p> - Método de pago.</p>
          <p> - Administración de cuentas.</p>
          <p> - Administración de recursos humanos.</p>
          <p> - Método de envío.</p>
          <p> - Gestión de mesas de restaurante.</p>
          <p> - Sistema multilingüe.</p>
          <p> - Unidad e ingredientes de cocina.</p>
          <p> - Participación con presencia de marca en eventos.</p>
          <p> - Acceso a cursos especializados.</p>
        </div>
      </div>
    </div>
    <div class="col s4 hide-on-small-only">
      <div class="card hoverable">
        <div class="card-image">
          <img src="img/webp/11.webp" alt="" class="responsive-img">
        </div>
        <div class="card-content">
          <h5>Paquete de fidelización</h5>
          <blockquote>
            <p>Precio</p>
            <p>₡75.000 mensuales</p>
          </blockquote>
          <p> - Todos los beneficios del paquete intermedio.</p>
          <p> - Ser miembro reconocido de la comunidad AGOC.</p>
          <p> - Acceso a perfil de cliente.</p>
          <p> - Acceso a campañas estratégicas.</p>
          <p> - Acceso de métricas mensuales.</p>
          <p> - Acceso a proveedores.</p>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
        </div>
      </div>
    </div>

    <!-- Componentes para pantallas pequeñas -->
    <div class="col s12 hide-on-med-and-up">
      <div class="card hoverable">
        <div class="card-image">
          <img src="img/webp/11.webp" alt="" class="responsive-img">
        </div>
        <div class="card-content">
          <h5>Paquete básico</h5>
          <blockquote>
            <p>Precio</p>
            <p>₡15.000 mensuales</p>
          </blockquote>
          <p> - Acceso al blog para anunciar eventos.</p>
          <p> - Acceso al directorio gastronómico.</p>
          <p> - Creación de página web básica para presencia en internet.</p>
          <p> - Acceso al canal de YouTube para capacitaciones y charlas.</p>
          <p> - Descuento en eventos futuros.</p>
        </div>
      </div>
    </div>
    <div class="col s12 hide-on-med-and-up">
      <div class="card hoverable">
        <div class="card-image">
          <img src="img/webp/2.webp" alt="" class="responsive-img">
        </div>
        <div class="card-content">
          <h5>Paquete intermedio</h5>
          <blockquote>
            <p>Precio</p>
            <p>₡55.000 mensuales</p>
          </blockquote>
          <p> - Todos los beneficios del paquete básico.</p>
          <p> - Software de punto de venta para restaurantes.</p>
          <p> - Software con administración del negocio CRM.</p>
          <p> - Software para ecommerce o venta en línea de comida.</p>
          <p> - Sistema para hacer reservaciones.</p>
          <p> - Sistema de gestión de compras.</p>
          <p> - Sistema de gestión de divisas.</p>
          <p> - Sistema de gestión de pedidos.</p>
          <p> - Sistema de gestión de producción.</p>
          <p> - Panel de control.</p>
          <p> - Informes en tiempo real.</p>
          <p> - Método de pago.</p>
          <p> - Administración de cuentas.</p>
          <p> - Administración de recursos humanos.</p>
          <p> - Método de envío.</p>
          <p> - Gestión de mesas de restaurante.</p>
          <p> - Sistema multilingüe.</p>
          <p> - Unidad e ingredientes de cocina.</p>
          <p> - Participación con presencia de marca en eventos.</p>
          <p> - Acceso a cursos especializados.</p>
        </div>
      </div>
    </div>
    <div class="col s12 hide-on-med-and-up">
      <div class="card hoverable">
        <div class="card-image">
          <img src="img/webp/11.webp" alt="" class="responsive-img">
        </div>
        <div class="card-content">
          <h5>Paquete de fidelización</h5>
          <blockquote>
            <p>Precio</p>
            <p>₡75.000 mensuales</p>
          </blockquote>
          <p> - Todos los beneficios del paquete intermedio.</p>
          <p> - Ser miembro reconocido de la comunidad AGOC.</p>
          <p> - Acceso a perfil de cliente.</p>
          <p> - Acceso a campañas estratégicas.</p>
          <p> - Acceso de métricas mensuales.</p>
          <p> - Acceso a proveedores.</p>
        </div>
      </div>
    </div>
  </div>
</div>


<?php require_once "templates/footer.php" ?>

<?php require_once "templates/header.php" ?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>AGOC - SOBRE NOSOTROS</title>
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  </head>
  <body>
    <div class="parallax-container">
      <div class="parallax"><img src="img/webp/5.webp" class="responsive-img"></div>
      <div class="parallax-text">
        <h2 class="center-align">Agrupación Gastronómica de Occidente - Sobre Nosotros</h2>
        <p class="flow-text center-align">Somos una organización que busca el bienestar colectivo de cada uno de sus miembros a través de la tecnología</p>
      </div>
    </div>

    <!-- Resto del contenido de la página -->

    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('.parallax');
        var instances = M.Parallax.init(elems);
      });
    </script>
      <div class="row">
        <div class="col s6 hide-on-small-only">
          <div class="card hoverable">
            <div class="card-content">
              <h5 class="center-align">¡Te damos la bienvenida a AGOC, tu plataforma de soluciones gastronómicas líder!</h5>
              <ul class="collapsible">
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Quién lidera la comunidad de empresarios y emprendimientos gastronómicos comprometidos en ofrecer soluciones técnicas y tecnológicas innovadoras para el sector?</div>
                  <div class="collapsible-body">
                    <span>AGOC, la Agrupación Gastronómica de Occidente, lidera con orgullo la comunidad de empresarios y emprendimientos gastronómicos comprometidos en ofrecer soluciones técnicas y tecnológicas innovadoras para el sector. Nos destacamos por nuestra pasión y compromiso en impulsar el desarrollo de la gastronomía mediante la integración de la tecnología en el ámbito culinario.</span>
                  </div>
                </li>
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿En qué se enfoca AGOC al brindar soluciones a sus miembros?</div>
                  <div class="collapsible-body">
                    <span>AGOC se enfoca en proporcionar a sus miembros soluciones integrales y de vanguardia. A través de nuestra amplia experiencia y conocimiento en innovación digital y asesoría técnica, brindamos el respaldo necesario para que los empresarios y emprendedores gastronómicos puedan adoptar las últimas tecnologías, tanto en software como en hardware, mejorando así su desempeño y competitividad en el mercado.</span>
                  </div>
                </li>
                <!-- Repite el mismo formato para las demás preguntas -->
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Cuál es el objetivo principal de AGOC?</div>
                  <div class="collapsible-body">
                    <span>Nuestro objetivo principal en AGOC es impulsar el crecimiento económico y profesional de la gastronomía nacional. Trabajamos arduamente para fortalecer la industria, colaborando estrechamente con nuestros miembros para fomentar la excelencia en el sector gastronómico y promover su reconocimiento a nivel nacional e internacional.</span>
                  </div>
                </li>
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Qué se promueve en la comunidad de AGOC?</div>
                  <div class="collapsible-body">
                    <span>En AGOC promovemos una comunidad sólida y colaborativa, donde los empresarios y emprendedores gastronómicos pueden conectarse, interactuar y compartir conocimientos y experiencias. Fomentamos un ambiente de apoyo mutuo, impulsando la colaboración y la sinergia entre nuestros miembros. Creemos en el poder de la comunidad para superar desafíos y alcanzar metas comunes.</span>
                  </div>
                </li>
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Qué ofrece AGOC para impulsar el éxito de sus miembros?</div>
                  <div class="collapsible-body">
                    <span>Para impulsar el éxito de nuestros miembros, AGOC ofrece una amplia gama de beneficios. Además de brindar soluciones tecnológicas y asesoría técnica de vanguardia, también proporcionamos oportunidades de networking, eventos exclusivos, acceso a recursos y herramientas especializadas, y la posibilidad de participar en proyectos conjuntos. Nuestro enfoque integral busca potenciar el crecimiento y la visibilidad de nuestros miembros en el mercado gastronómico.</span>
                  </div>
                </li>
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Cuál es la invitación final de AGOC para los interesados en unirse a la comunidad?</div>
                  <div class="collapsible-body">
                    <span>La invitación final de AGOC es a unirse a nuestra comunidad y formar parte de la transformación tecnológica e innovadora en el sector gastronómico. Si eres un empresario o emprendedor gastronómico en busca de soluciones y apoyo para alcanzar tus metas, te animamos a unirte a AGOC y ser parte de una comunidad comprometida en impulsar el éxito y el crecimiento colectivo en la gastronomía nacional. ¡Te damos la bienvenida a AGOC, tu plataforma de soluciones gastronómicas líder!</span>
                  </div>
                </li>
              </ul>
              <script>
              document.addEventListener('DOMContentLoaded', function() {
                var elems = document.querySelectorAll('.collapsible');
                var instances = M.Collapsible.init(elems);
              });
              </script>
            </div>
          </div>
        </div>
        <div class="col s12 hide-on-med-and-up">
          <div class="card hoverable">
            <div class="card-content">
              <h5 class="center-align">¡Te damos la bienvenida a AGOC, tu plataforma de soluciones gastronómicas líder!</h5>
              <ul class="collapsible">
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Quién lidera la comunidad de empresarios y emprendimientos gastronómicos comprometidos en ofrecer soluciones técnicas y tecnológicas innovadoras para el sector?</div>
                  <div class="collapsible-body">
                    <span>AGOC, la Agrupación Gastronómica de Occidente, lidera con orgullo la comunidad de empresarios y emprendimientos gastronómicos comprometidos en ofrecer soluciones técnicas y tecnológicas innovadoras para el sector. Nos destacamos por nuestra pasión y compromiso en impulsar el desarrollo de la gastronomía mediante la integración de la tecnología en el ámbito culinario.</span>
                  </div>
                </li>
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿En qué se enfoca AGOC al brindar soluciones a sus miembros?</div>
                  <div class="collapsible-body">
                    <span>AGOC se enfoca en proporcionar a sus miembros soluciones integrales y de vanguardia. A través de nuestra amplia experiencia y conocimiento en innovación digital y asesoría técnica, brindamos el respaldo necesario para que los empresarios y emprendedores gastronómicos puedan adoptar las últimas tecnologías, tanto en software como en hardware, mejorando así su desempeño y competitividad en el mercado.</span>
                  </div>
                </li>
                <!-- Repite el mismo formato para las demás preguntas -->
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Cuál es el objetivo principal de AGOC?</div>
                  <div class="collapsible-body">
                    <span>Nuestro objetivo principal en AGOC es impulsar el crecimiento económico y profesional de la gastronomía nacional. Trabajamos arduamente para fortalecer la industria, colaborando estrechamente con nuestros miembros para fomentar la excelencia en el sector gastronómico y promover su reconocimiento a nivel nacional e internacional.</span>
                  </div>
                </li>
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Qué se promueve en la comunidad de AGOC?</div>
                  <div class="collapsible-body">
                    <span>En AGOC promovemos una comunidad sólida y colaborativa, donde los empresarios y emprendedores gastronómicos pueden conectarse, interactuar y compartir conocimientos y experiencias. Fomentamos un ambiente de apoyo mutuo, impulsando la colaboración y la sinergia entre nuestros miembros. Creemos en el poder de la comunidad para superar desafíos y alcanzar metas comunes.</span>
                  </div>
                </li>
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Qué ofrece AGOC para impulsar el éxito de sus miembros?</div>
                  <div class="collapsible-body">
                    <span>Para impulsar el éxito de nuestros miembros, AGOC ofrece una amplia gama de beneficios. Además de brindar soluciones tecnológicas y asesoría técnica de vanguardia, también proporcionamos oportunidades de networking, eventos exclusivos, acceso a recursos y herramientas especializadas, y la posibilidad de participar en proyectos conjuntos. Nuestro enfoque integral busca potenciar el crecimiento y la visibilidad de nuestros miembros en el mercado gastronómico.</span>
                  </div>
                </li>
                <li>
                  <div class="collapsible-header"><i class="material-icons">keyboard_arrow_down</i>¿Cuál es la invitación final de AGOC para los interesados en unirse a la comunidad?</div>
                  <div class="collapsible-body">
                    <span>La invitación final de AGOC es a unirse a nuestra comunidad y formar parte de la transformación tecnológica e innovadora en el sector gastronómico. Si eres un empresario o emprendedor gastronómico en busca de soluciones y apoyo para alcanzar tus metas, te animamos a unirte a AGOC y ser parte de una comunidad comprometida en impulsar el éxito y el crecimiento colectivo en la gastronomía nacional. ¡Te damos la bienvenida a AGOC, tu plataforma de soluciones gastronómicas líder!</span>
                  </div>
                </li>
              </ul>
              <script>
              document.addEventListener('DOMContentLoaded', function() {
                var elems = document.querySelectorAll('.collapsible');
                var instances = M.Collapsible.init(elems);
              });
              </script>
            </div>
          </div>
        </div>
        <style media="screen">
        .image-container {
          margin-top: 10px;
          width: 537px; /* Ancho fijo del contenedor */
          height: 537px; /* Alto fijo del contenedor */
          overflow: hidden; /* Oculta el contenido que se desborda del contenedor */
        }

        .image-container img {
          width: 100%; /* Ancho del 100% para ocupar todo el espacio del contenedor */
          height: auto; /* Altura automática para mantener la proporción de la imagen */
        }
        </style>
        <div class="col s6 hide-on-small-only">
          <div class=" image-container">
            <img src="img/webp/6.webp" alt="">
          </div>
        </div>
      </div>


<?php require_once "templates/footer.php" ?>

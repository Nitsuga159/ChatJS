<?php require_once "templates/header.php" ?>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <title>AGOC - INICIO</title>
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  </head>
  <body>
    <div class="parallax-container">
      <div class="parallax"><img src="img/webp/5.webp" class="responsive-img"></div>
      <div class="parallax-text">
        <h2 class="center-align">Agrupación Gastronómica de Occidente - AGOC</h2>
        <p class="flow-text center-align">Somos una organización que busca el bienestar colectivo de cada uno de sus miembros a través de la tecnología</p>
      </div>
    </div>

    <!-- Resto del contenido de la página -->

    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('.parallax');
        var instances = M.Parallax.init(elems);
      });
    </script>
    <div class="container">
      <div class="row">
        <div class="col s6">
          <div class="card hoverable">
            <div class="card-image">
              <img src="img/webp/11.webp" alt="" class="responsive-img">
            </div>
            <div class="card-content">
              <h5>Visión</h5>
              <p>Ser la comunidad de empresarios y emprendimientos gastronómicos que aporte soluciones técnicas y tecnologicas de manera solidaria. Buscando el beneficio económico y profesional de la gastronomía nacional.
              </p>
              <br>
              <br>
            </div>
          </div>
        </div>
        <div class="col s6">
          <div class="card hoverable">
            <div class="card-image">
              <img src="img/webp/2.webp" alt="" class="responsive-img">
            </div>
            <div class="card-content">
              <h5>Misión</h5>
              <p>Ser una agrupación que otorgue soluciones de innovación digital y asesoría técnica. Acompañando a nuestros miembros en la implementación de tecnologías (software y Hardware), que les permita mejorar, desarrollar e implementar servicio integral y posicionamiento de su negocio.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

<?php require_once "templates/footer.php" ?>
